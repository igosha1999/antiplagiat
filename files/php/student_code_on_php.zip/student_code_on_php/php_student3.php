<?php
//initialize with a random integer within range
$diceNumber = mt_rand(1, 6);

//initialize
$numText = "";

echo 'Dice show number ' . $numText . '.';
//calling switch statement
switch ($diceNumber) {
  case 6:
    $numText = "Six";
    echo $numText;
    break;
  case 2:
    $numText = "Two";
    break;
  case 3:
  case 4:
    // case 3 and 4 will go to this line
    $numText = "Three or Four";
    break;
  case 1:
    $numText = "One";
    break;
  case 5:
    $numText = "Five";
    echo $numText;
  // break; //without specify break or return it will continue execute to next case.
  default:
    $numText = "unknown";
}

//display result

?>
