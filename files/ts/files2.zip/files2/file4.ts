// Named function
function add(x: number, y: number) {
  return x + y;
}

// Anonymous function
let myAdd = function (x: number, y: number) {
  return x + y;
};
