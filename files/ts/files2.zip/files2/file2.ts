function addNumbers1(a: number, b: number) {
  return a + b;
}

var sum: number = addNumbers1(10, 15)

console.log('Sum of the two numbers is: ' + sum);
