// Named function
let myAdd2 = function (x: number, y: number) {
  return x + y;
};

// Anonymous function
function add1(x: number, y: number) {
  return x + y;
}
